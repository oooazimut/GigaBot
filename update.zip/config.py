import logging
from collections import namedtuple

# TOKEN = '5763965681:AAFHBI6RB8fzBKAzqf4fK1JfMs_8Jxp4PMQ'
TOKEN = '6525353343:AAHW8JVm3wya_x52NdUXM5lAuBqZX-afgL8'

NetData = namedtuple('NetData', ['remotehost', 'remoteport', 'localhost', 'localport'])
NET_DATA = NetData('kitvideovpn.ru', 8454, '192.168.1.156', 502)

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(message)s')
_logger = logging.getLogger()

PASSWORD = '1306955'

GAS_ROOMS = ('насосная', 'пробная')
GAS_SENS_IDS = ('насосная.1', 'насосная.2', 'насосная.3', 'насосная.4')
GAS_SENS_DESCS = ('5.1', '5.2', '5.3', '5.4')
GAS_SENS_PROB_IDS = ('пробная.1', 'пробная.2')
GAS_SENS_PROB_DESCS = ('3.8', '4.1')
PUMPS_IDS = ('H-1.1', 'H-1.2', 'H-3', 'H-2.1', 'H-2.2')
PUMPS_DESCS = ('АИ-92', 'АИ-95/98', 'Внутр.', 'ДТ', 'ДТ')

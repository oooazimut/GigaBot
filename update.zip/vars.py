uzas = 0
permissions = 0
pumps = 0
shifters = []
